<div class="container">
	<div class="row">
        <div class="col-xs-12">
            <div class="modal-header text-info"><h2>ARRIVALS</h2><h5>DHAKA INTERNATIONAL AIRPORT</h5><h5>DATE: TIME: DAY:</h5></div>
        </div>
    </div>
    <div class="row">
    	<div class="col-xs-12">
        	<div class="table-responsive">
            	<table class="table table-striped table-hover">
                    	<tr class="text-danger">
                        	<th>FLIGHT</th>
                            <th>AIRLINE</th>
                            <th>RUTE</th>
                            <th>PRESENT<br>LOCATION</th>
                            <th>NEXT<br>DESTINATION</th>
                            <th>SHEDULE<br>TIME</th>
                            <th>ESTIMATED<br>TIME</th>
                            <th>TERMINAL</th>
                            <th>GATE</th>
                            <th>STATUS</th>
                        </tr>
                    	<tr>
                        	<td>JFD21545</td>
                            <td>Bangladesh Airline</td>
                            <td>New York Dhaka</td>
                            <td>New York</td>
                            <td>Dhaka</td>
                            <td>22:45</td>
                            <td>9:10</td>
                            <td>Rojonigondha</td>
                            <td>03</td>
                            <td>Landed</td>
                        </tr>
                </table>
            </div>
        </div>
    </div>
</div>
